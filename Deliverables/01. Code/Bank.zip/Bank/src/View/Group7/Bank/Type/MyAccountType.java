/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Group7.Bank.Type;

/**
 *
 * @author naimi_000
 */
public enum MyAccountType {

    SAVING,
    CHECKING,
    MYAC
}
