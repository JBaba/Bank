/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.asd.group7.common.app;

import com.asd.group7.common.app.account.DefaultAccount;
import com.asd.group7.common.app.comparator.AccountComparator;
import com.asd.group7.common.lib.ASDArrayList;
import com.asd.group7.common.lib.account.AAccount;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author james
 */
public class Test {

    public static void main(String args[]) {
        ASDArrayList accountList = new ASDArrayList();

        AAccount account1 = new DefaultAccount();
        account1.setAcctNumber("Samita");
        accountList.add(account1);

        AAccount account2 = new DefaultAccount();
        account2.setAcctNumber("James");
        accountList.add(account2);

        AAccount account3 = new DefaultAccount();
        account3.setAcctNumber("Mandira");
        accountList.add(account3);

        AAccount account4 = new DefaultAccount();
        account4.setAcctNumber("Ganga");
        accountList.add(account4);

        try {
            Iterator it = accountList.getSortedIterator(new AccountComparator("acctNumber"));
            while (it.hasNext()) {
                AAccount acct = (AAccount) it.next();
                System.out.println(acct.getAcctNumber());
            }
        } catch (Exception ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
